// This file is being used for devlopment by providing an entrypoint for 
// the build system

#include <iostream>
#include "trm/subs.h"
#include "trm/binary.h"
#include "trm/colly.h"
#include "trm/roche.h"

int main() {
    std::cout << "Hello, World! Just a quick test" << std::endl;
    // Test subs

    // Finish
    return 0;
}
.. subs documentation master file, created by
   sphinx-quickstart on Sat Aug 24 22:32:56 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to subs's documentation!
================================

**subs** provides a C++ library of commonly needed routines, along with a
few programs. I substantially revised it in August 2013 and these pages
are part of that re-vamp. They are very much work in progress.

Contents:

.. toctree::
   :maxdepth: 1

   programs


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


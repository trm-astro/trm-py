Programs distributed with subs
==============================

subs is mostly a library of routines but does come with a few
programs which are listed here.

.. toctree::
   :maxdepth: 1

   _store/gap_cc
   _store/tcorr_cc 
   _store/weekday_cc

cpp-colly: C++ routines for accessing molly spectra
===================================================

'colly' provides a small set of utilities and an associated C++
library for manipulating molly spectra. 

Installation order: subs --> colly

See the README.rst file for cpp-subs on my github pages for some
information on installation. That page explains likely problems you
might have locating pgplot headers and libraries. The same can happen
at this point when you try to locate subs headers and libraries, so
look at that page to see what it says about CPPFLAGS and LDFLAGS.

Tom Marsh

